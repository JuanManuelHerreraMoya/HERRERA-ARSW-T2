package edu.eci.arsw.OpenWather;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenWatherApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenWatherApplication.class, args);
	}

}
