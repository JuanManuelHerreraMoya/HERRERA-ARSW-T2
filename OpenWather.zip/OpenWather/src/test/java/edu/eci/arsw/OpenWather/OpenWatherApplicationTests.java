package edu.eci.arsw.OpenWather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenWatherApplicationTests {

	@Test
	void contextLoads() {
	}

}
